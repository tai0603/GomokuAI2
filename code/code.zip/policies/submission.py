import random
import math
import gomoku as gm
from copy import deepcopy

class MCTSNode:
    def __init__(self, game_state, parent=None, move=None):
        self.game_state = game_state
        self.parent = parent
        self.move = move
        self.children = []
        self.wins = 0
        self.visits = 0
        self.untried_actions = list(self.game_state.valid_actions())  # Convert to list
        self.player_just_moved = game_state.current_player()

    def UCT_select_child(self):
        return max(self.children, key=lambda c: c.wins / c.visits + math.sqrt(2 * math.log(self.visits) / c.visits))

    def add_child(self, move, game_state):
        child_node = MCTSNode(game_state, parent=self, move=move)
        self.untried_actions.remove(move)  # Now it's a list, so remove works
        self.children.append(child_node)
        return child_node

    def update(self, result):
        self.visits += 1
        self.wins += result


def heuristic_simulation(state):
    valid_actions = state.valid_actions()
    # Implement your heuristic here
    # Example: prioritize actions near the center or block opponent's winning move
    if valid_actions:
        # Simple heuristic: choose the action closest to the center
        center = [len(state.board) // 2, len(state.board[0]) // 2]
        action = min(valid_actions, key=lambda x: abs(x[0] - center[0]) + abs(x[1] - center[1]))
        return action
    else:
        return None

def MCTS(root_state, itermax):
    root_node = MCTSNode(game_state=root_state)

    for _ in range(itermax):
        node = root_node
        state = deepcopy(root_state)  # Copy the game state

        # Selection
        while node.untried_actions and node.children:
            node = node.UCT_select_child()
            state = state.perform(node.move)

        # Expansion
        if node.untried_actions:
            move = random.choice(node.untried_actions)
            state = state.perform(move)
            node = node.add_child(move, state)

        # Simulation
        if not state.is_game_over():
            while state.valid_actions():
                action = heuristic_simulation(state)
                if action is not None:
                    state = state.perform(action)

        # Backpropagation
        while node is not None:
            node.update(1 if state.current_player() == node.player_just_moved else 0)
            node = node.parent

    return max(root_node.children, key=lambda c: c.visits).move
class Submission:
    def __init__(self, board_size, win_size):
        self.itermax = 1000

    def __call__(self, state):
        return MCTS(state, self.itermax)

# Example usage
if __name__ == "__main__":
    ai = Submission(15, 5)
    state = gm.GomokuState.blank(15, 5)

    while not state.is_game_over():
        if state.current_player() == gm.MAX:
            move = ai(state)
            state = state.perform(move)
        else:
            # Handle move for the other player (MIN or human)
            pass
